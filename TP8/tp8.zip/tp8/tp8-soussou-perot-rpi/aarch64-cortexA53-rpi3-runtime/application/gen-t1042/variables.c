#include "variables.h"

/* Définition des variables déclarées dans variables.h */
Scheduler__main_mem scheduler_mem;
Scheduler__main_out scheduler_out;
