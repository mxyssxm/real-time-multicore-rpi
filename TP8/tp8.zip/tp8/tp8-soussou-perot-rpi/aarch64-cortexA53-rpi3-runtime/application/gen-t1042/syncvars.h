#ifndef SYNCVARS_H
#define SYNCVARS_H

#include "extern-types.h"

extern LOPHT_PC_TYPE loc_pc_0;
extern LOPHT_PC_TYPE loc_pc_1;

#endif
