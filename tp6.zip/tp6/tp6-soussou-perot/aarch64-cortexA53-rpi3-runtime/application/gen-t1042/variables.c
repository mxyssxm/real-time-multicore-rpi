#include "variables.h"

DATA_SECTION_ATTR(".data.x")
int x;

DATA_SECTION_ATTR(".data.y")
int y;

DATA_SECTION_ATTR(".data.u")
int u;

DATA_SECTION_ATTR(".data.z")
int z = 123;   
