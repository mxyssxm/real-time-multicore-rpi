#include "scheduler.h"

// Version RPi : on ne fait rien ici, mais on garde la fonction
// pour satisfaire l'édition de liens si jamais elle est appelée quelque part.
void print_scheduler_state(Scheduler_data__scheduler_state s)
{
    (void)s;  // évite un warning "unused parameter"
}
