/* variable definition header */
#ifndef VARIABLES_H
#define VARIABLES_H

#include "extern-types.h"

/* (pour l’instant, aucune variable globale déclarée ici pour le TP7) */

#endif /* VARIABLES_H */
