#include "variables.h"

/* Pas de définition de variables globales pour le TP7 ici */
