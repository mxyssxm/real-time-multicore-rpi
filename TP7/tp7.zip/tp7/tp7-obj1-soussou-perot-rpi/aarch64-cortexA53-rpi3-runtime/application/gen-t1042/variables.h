/* variable definition header */
#ifndef VARIABLES_H
#define VARIABLES_H

#include "extern-types.h"

/* Déclarations des variables de communication C
 * pour l'exemple de l'objectif 1
 */
extern int x;
extern int y;
extern int u;
extern int z;

#endif /* VARIABLES_H */
