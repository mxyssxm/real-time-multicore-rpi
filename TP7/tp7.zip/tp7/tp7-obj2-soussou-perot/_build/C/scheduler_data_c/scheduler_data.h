/* --- Generated the 28/11/2025 at 11:48 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. nov. 12 16:58:21 CET 2025) --- */
/* --- Command line: /Users/meyssem/.opam/heptagon-4.14/bin/heptc -target c -targetpath _build/C scheduler_data.ept scheduler.ept externc.epi --- */

#ifndef SCHEDULER_DATA_H
#define SCHEDULER_DATA_H

#include "scheduler_data_types.h"
#endif // SCHEDULER_DATA_H
